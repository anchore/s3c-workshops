# my-python-app

Small demo Flask service used in the Anchore Enterprise Visibility lab.

The dependencies in `requirements.txt` are intentionally pinned to old
versions with known CVEs — this is a teaching artifact, not something you
should ever ship.
