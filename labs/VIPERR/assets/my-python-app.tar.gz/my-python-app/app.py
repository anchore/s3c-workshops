"""Tiny demo HTTP service used in the Anchore Enterprise Visibility lab.

Intentionally pins old, vulnerable versions of its dependencies in
requirements.txt so the resulting SBOM surfaces real CVEs when scanned.
Do not run this in production.
"""
from flask import Flask, jsonify, request
import requests
import yaml

app = Flask(__name__)


@app.route("/health")
def health():
    return jsonify(status="ok")


@app.route("/echo", methods=["POST"])
def echo():
    payload = yaml.safe_load(request.data)
    return jsonify(received=payload)


@app.route("/proxy", methods=["POST"])
def proxy():
    payload = yaml.safe_load(request.data)
    upstream = payload.get("url")
    response = requests.get(upstream, timeout=5)
    return response.text


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
